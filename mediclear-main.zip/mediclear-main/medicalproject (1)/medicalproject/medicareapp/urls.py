from django.urls import path
from medicareapp import views

urlpatterns = [
    path('', views.index, name='login'),          # This is your home/login page
    path('register/', views.register, name='signup'), # Fixes the signup error
    path('dashboard/', views.dashboard, name='dashboard'),
    path('logout/', views.logout_view, name='logout'), # Essential for logout button
    path('forgot-password/', views.password_reset_request, name='password_reset_request'),
    
    # AI/LLM Endpoints
    path('api/analyze-report/', views.analyze_report, name='analyze_report'),
    path('api/explain-term/', views.explain_term, name='explain_term'),
    path('api/chat/', views.ai_chat, name='ai_chat'),
    path('api/delete-report/<int:report_index>/', views.delete_report, name='delete_report'),
]   