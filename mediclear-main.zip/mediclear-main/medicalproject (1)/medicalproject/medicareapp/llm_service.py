"""
MediClear AI - Healthcare Assistant
Using Groq API with Llama 3.3 70B
"""
import os
import requests
from django.conf import settings


class MedicalLLMService:
    """Healthcare AI Assistant using Groq API"""
    
    def __init__(self):
        # Get API key from settings or environment - using the key from llmbot
        self.api_key = getattr(settings, 'GROQ_API_KEY', None) or os.environ.get('GROQ_API_KEY', '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')
        self.api_url = "https://api.groq.com/openai/v1/chat/completions"
        self.model = "llama-3.3-70b-versatile"
        print("✅ MediClear AI initialized with Groq!")
    
    def _get_system_prompt(self):
        """Healthcare system prompt"""
        return """You are MediClear AI, an expert healthcare assistant providing comprehensive medical information.

COMMON REFERENCE RANGES:
- Blood Pressure: Normal <120/80, Elevated 120-129/<80, High ≥130/80
- Fasting Blood Sugar: Normal 70-99, Prediabetes 100-125, Diabetes ≥126 mg/dL
- HbA1c: Normal <5.7%, Prediabetes 5.7-6.4%, Diabetes ≥6.5%
- Total Cholesterol: Desirable <200, Borderline 200-239, High ≥240 mg/dL
- LDL: Optimal <100, Near optimal 100-129, High ≥160 mg/dL
- HDL: Low <40(men)/<50(women), Good 40-59, Excellent ≥60 mg/dL
- Triglycerides: Normal <150, High ≥200 mg/dL
- Hemoglobin: Men 13.5-17.5, Women 12.0-16.0 g/dL
- WBC: 4,000-11,000 cells/mcL
- RBC: Men 4.5-5.9, Women 4.0-5.2 million cells/mcL
- Platelets: 150,000-450,000/mcL
- ALT: 7-56 U/L
- AST: 10-40 U/L
- Creatinine: Men 0.7-1.3, Women 0.6-1.1 mg/dL
- TSH: 0.4-4.0 mIU/L
- Vitamin D: 30-100 ng/mL
- Vitamin B12: 200-900 pg/mL

GUIDELINES:
- Analyze ALL parameters provided in the report
- Be precise with numbers and ranges for every parameter
- Use simple language that patients can understand
- Format with markdown, headers, bullet points
- Use emojis: ✅ ⚠️ 🔴 🟢 for status indicators
- Provide context and explanation for EACH parameter
- Always recommend consulting a doctor for medical advice
- Never diagnose or prescribe medications
- Be empathetic and supportive

⚠️ I provide information, not medical advice. Always consult your doctor."""

    def _call_groq_api(self, messages):
        """Make API call to Groq"""
        try:
            response = requests.post(
                self.api_url,
                headers={
                    "Authorization": f"Bearer {self.api_key}",
                    "Content-Type": "application/json"
                },
                json={
                    "model": self.model,
                    "messages": messages,
                    "temperature": 0.7,
                    "max_tokens": 2048
                },
                timeout=30
            )
            
            result = response.json()
            
            if "choices" in result:
                return result["choices"][0]["message"]["content"]
            else:
                error_msg = result.get("error", {}).get("message", "Unknown error from Groq API")
                print(f"⚠️ Groq API error: {error_msg}")
                return None
                
        except requests.exceptions.Timeout:
            print("⚠️ Groq API timeout")
            return None
        except Exception as e:
            print(f"⚠️ Groq API error: {e}")
            return None

    def analyze_medical_report(self, report_data: dict, user_profile: dict = None) -> str:
        """Analyze medical report using Groq AI"""
        
        # Build the analysis prompt
        prompt = f"""Please analyze this medical report and provide a comprehensive health assessment:

**Report Values:**
- Blood Pressure: {report_data.get('bp', 'N/A')} mmHg
- Blood Sugar: {report_data.get('sugar', 'N/A')} mg/dL
- Cholesterol: {report_data.get('chol', 'N/A')} mg/dL
- Hemoglobin: {report_data.get('hb', 'N/A')} g/dL

"""
        if user_profile:
            prompt += f"""**Patient Profile:**
- Name: {user_profile.get('full_name', 'N/A')}
- Gender: {user_profile.get('gender', 'N/A')}
- Date of Birth: {user_profile.get('dob', 'N/A')}
- Blood Group: {user_profile.get('blood_group', 'N/A')}

"""
        
        prompt += """Please provide:
1. **Overall Health Summary** with status indicators (✅ Normal, ⚠️ Borderline, 🔴 Needs Attention)
2. **Individual Parameter Analysis** - explain each value and what it means
3. **Recommendations** - lifestyle and dietary suggestions
4. **When to See a Doctor** - any concerning findings

Format your response with clear headers and bullet points."""

        messages = [
            {"role": "system", "content": self._get_system_prompt()},
            {"role": "user", "content": prompt}
        ]
        
        response = self._call_groq_api(messages)
        
        if response:
            return response
        else:
            # Fallback response if API fails
            return self._analyze_report_fallback(report_data)
    
    def _analyze_report_fallback(self, report_data):
        """Fallback analysis when API is unavailable"""
        bp = report_data.get('bp', 0)
        sugar = report_data.get('sugar', 0)
        chol = report_data.get('chol', 0)
        hb = report_data.get('hb', 0)
        
        analysis = "## 📋 Medical Report Analysis\n\n"
        
        # Blood Pressure
        if bp:
            if bp < 120:
                analysis += f"### Blood Pressure: {bp} mmHg ✅\nYour blood pressure is in the **normal range**. Keep maintaining a healthy lifestyle!\n\n"
            elif bp < 130:
                analysis += f"### Blood Pressure: {bp} mmHg ⚠️\nYour blood pressure is **elevated**. Consider reducing salt intake and increasing physical activity.\n\n"
            else:
                analysis += f"### Blood Pressure: {bp} mmHg 🔴\nYour blood pressure is **high**. Please consult a doctor for proper evaluation.\n\n"
        
        # Blood Sugar
        if sugar:
            if sugar < 100:
                analysis += f"### Blood Sugar: {sugar} mg/dL ✅\nYour fasting blood sugar is **normal**. Great job!\n\n"
            elif sugar < 126:
                analysis += f"### Blood Sugar: {sugar} mg/dL ⚠️\nYour blood sugar indicates **prediabetes**. Consider dietary changes.\n\n"
            else:
                analysis += f"### Blood Sugar: {sugar} mg/dL 🔴\nYour blood sugar is in the **diabetic range**. Please see a doctor.\n\n"
        
        # Cholesterol
        if chol:
            if chol < 200:
                analysis += f"### Cholesterol: {chol} mg/dL ✅\nYour cholesterol is **desirable**. Keep eating healthy!\n\n"
            elif chol < 240:
                analysis += f"### Cholesterol: {chol} mg/dL ⚠️\nYour cholesterol is **borderline high**. Reduce saturated fats.\n\n"
            else:
                analysis += f"### Cholesterol: {chol} mg/dL 🔴\nYour cholesterol is **high**. Please consult a doctor.\n\n"
        
        # Hemoglobin
        if hb:
            if 12 <= hb <= 17.5:
                analysis += f"### Hemoglobin: {hb} g/dL ✅\nYour hemoglobin is **normal**. Good!\n\n"
            elif hb < 12:
                analysis += f"### Hemoglobin: {hb} g/dL ⚠️\nYour hemoglobin is **low**. Consider iron-rich foods or supplements.\n\n"
            else:
                analysis += f"### Hemoglobin: {hb} g/dL ⚠️\nYour hemoglobin is **elevated**. Please consult a doctor.\n\n"
        
        analysis += "\n---\n⚠️ **Disclaimer:** This is an automated analysis. Always consult a healthcare professional for proper medical advice."
        
        return analysis
    
    def explain_medical_term(self, term: str) -> str:
        """Explain medical term using Groq AI"""
        
        prompt = f"""Please explain the medical term "{term}" in simple, easy-to-understand language.

Include:
1. **What it is** - a simple definition
2. **Why it matters** - its importance for health
3. **Normal ranges** (if applicable)
4. **Related conditions** - what happens when it's abnormal

Keep the explanation patient-friendly and use bullet points for clarity."""

        messages = [
            {"role": "system", "content": self._get_system_prompt()},
            {"role": "user", "content": prompt}
        ]
        
        response = self._call_groq_api(messages)
        
        if response:
            return response
        else:
            return f"I apologize, but I couldn't retrieve information about '{term}' at the moment. Please try again later or consult with your healthcare provider."
    
    def chat(self, user_message: str, conversation_history: list = None) -> str:
        """Chat about health topics using Groq AI"""
        
        messages = [{"role": "system", "content": self._get_system_prompt()}]
        
        # Add conversation history if provided
        if conversation_history:
            for msg in conversation_history[-10:]:  # Keep last 10 messages for context
                if msg.get('role') in ['user', 'assistant']:
                    messages.append({
                        "role": msg['role'],
                        "content": msg['content']
                    })
        
        # Add current message
        messages.append({"role": "user", "content": user_message})
        
        response = self._call_groq_api(messages)
        
        if response:
            return response
        else:
            # Fallback to simple responses
            return self._chat_fallback(user_message)
    
    def _chat_fallback(self, user_message: str) -> str:
        """Fallback chat responses when API is unavailable"""
        msg = user_message.lower()
        
        # Greeting detection
        greetings = ["hi", "hello", "hey", "good morning", "good afternoon", "good evening"]
        if any(msg.startswith(g) for g in greetings) or msg in greetings:
            return """## 👋 Hello! I'm MediClear AI

Great to meet you! I'm here to help you understand your health better.

**I can help you with:**
- 📋 Understanding medical reports and lab results
- 🩸 Blood pressure questions
- 💛 Cholesterol information  
- 🍬 Blood sugar and diabetes
- 🔴 Hemoglobin and anemia
- 💪 General health and wellness tips

**What would you like to know about today?**"""
        
        # Thank you
        if "thank" in msg:
            return """You're very welcome! 😊

Feel free to ask me anything else about your health. I'm here to help!

**Need more information about:**
- Your medical reports?
- Specific health conditions?
- Lifestyle and wellness tips?

Just ask away! 🩺"""
        
        return """I apologize, but I'm having trouble connecting to my AI service right now. 

Please try again in a moment, or you can ask me about:
- Blood pressure ranges
- Cholesterol levels
- Blood sugar information
- Hemoglobin values

I'm here to help! 🩺"""


# Create singleton instance
llm_service = MedicalLLMService()
