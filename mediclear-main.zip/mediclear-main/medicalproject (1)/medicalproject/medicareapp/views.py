from django.shortcuts import render, redirect
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth.decorators import login_required
import datetime
from django.contrib.auth.models import User
from django.contrib import messages
from django.shortcuts import render, redirect
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import json
import random
import hashlib
import re
from PIL import Image
import io

# Import LLM Service
from .llm_service import llm_service

# Try to import OCR
try:
    import pytesseract
    # Configure Tesseract path (adjust if your installation path is different)
    pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'
    OCR_AVAILABLE = True
except ImportError:
    OCR_AVAILABLE = False

# Try to import PDF handler
try:
    import fitz  # PyMuPDF
    PDF_AVAILABLE = True
except ImportError:
    PDF_AVAILABLE = False

def extract_text_from_pdf(pdf_file):
    """Extract text directly from PDF using PyMuPDF"""
    try:
        # Read PDF content
        pdf_bytes = pdf_file.read()
        pdf_file.seek(0)  # Reset file pointer
        
        # Open PDF with PyMuPDF
        doc = fitz.open(stream=pdf_bytes, filetype="pdf")
        
        text = ""
        for page in doc:
            text += page.get_text()
        
        doc.close()
        return text.strip()
    except Exception as e:
        print(f"PDF text extraction failed: {e}")
        return None

def extract_medical_values_from_image(image_file):
    """Extract medical values from uploaded image or PDF using OCR and AI"""
    try:
        file_name = image_file.name.lower()
        text = None
        
        # Check if it's a PDF file
        if file_name.endswith('.pdf'):
            print(f"\n{'='*50}")
            print(f"PROCESSING PDF FILE: {image_file.name}")
            print(f"{'='*50}")
            
            if PDF_AVAILABLE:
                text = extract_text_from_pdf(image_file)
                if text:
                    print(f"PDF TEXT EXTRACTED ({len(text)} chars):")
                    print(text[:1000])  # Print first 1000 chars
                    print(f"{'='*50}\n")
            else:
                print("PDF library not available!")
                return None, None
        else:
            # It's an image file
            print(f"\n{'='*50}")
            print(f"PROCESSING IMAGE FILE: {image_file.name}")
            print(f"{'='*50}")
            
            image = Image.open(image_file)
            
            if OCR_AVAILABLE:
                text = pytesseract.image_to_string(image)
                print(f"OCR TEXT EXTRACTED ({len(text)} chars):")
                print(text[:1000])
                print(f"{'='*50}\n")
            else:
                print("OCR not available!")
                return None, None
        
        if not text or not text.strip():
            print("No text extracted from file")
            return None, None
        
        # Use AI to extract ALL medical values from the OCR text
        prompt = f"""You are a medical data extraction assistant. Extract ALL numeric medical test values from this report.

MEDICAL REPORT TEXT:
{text}

INSTRUCTIONS:
1. Find ALL numeric values with their test names
2. Return ONLY a valid JSON object
3. Use simple lowercase keys (no spaces, use underscore)
4. Include the numeric value only (no units)

EXAMPLE OUTPUT FORMAT:
{{"hemoglobin": 14.5, "wbc": 7500, "rbc": 5.2, "platelets": 250000, "glucose": 95, "cholesterol": 180, "creatinine": 1.0, "bp_systolic": 120, "bp_diastolic": 80}}

Return ONLY the JSON object, nothing else. If no values found, return: {{}}"""
        
        try:
            ai_response = llm_service.chat(prompt)
            print(f"\n{'='*50}")
            print(f"AI RESPONSE:")
            print(f"{'='*50}")
            print(ai_response)
            print(f"{'='*50}\n")
            
            # Extract JSON from AI response - handle nested braces
            json_match = re.search(r'\{[^{}]*\}', ai_response)
            if json_match:
                json_str = json_match.group(0)
                print(f"Found JSON: {json_str}")
                values = json.loads(json_str)
                print(f"Parsed values: {values}")
                if values:
                    return values, text
            
            # If no JSON found or empty, try regex extraction
            print("Falling back to regex extraction...")
            return extract_values_with_regex(text), text
                
        except json.JSONDecodeError as e:
            print(f"JSON parsing failed: {e}")
            return extract_values_with_regex(text), text
        except Exception as e:
            print(f"AI extraction failed: {e}")
            return extract_values_with_regex(text), text
        
    except Exception as e:
        print(f"Error extracting values from image: {e}")
        import traceback
        traceback.print_exc()
        return None, None


def extract_values_with_regex(text):
    """Fallback: Extract values using comprehensive regex patterns"""
    values = {}
    text_lower = text.lower()
    
    # Common medical value patterns - more comprehensive
    patterns = {
        'hemoglobin': [r'(?:hb|hemoglobin|hgb|haemoglobin)[:\s]*(\d+\.?\d*)', r'(\d+\.?\d*)\s*(?:g/dl|gm/dl|g/l).*(?:hb|hemoglobin)'],
        'wbc': [r'(?:wbc|white\s*blood\s*cells?|leucocytes?)[:\s]*(\d+\.?\d*)', r'(\d+\.?\d*)\s*(?:/cumm|cells/cumm|/ul).*(?:wbc|white)'],
        'rbc': [r'(?:rbc|red\s*blood\s*cells?|erythrocytes?)[:\s]*(\d+\.?\d*)', r'(\d+\.?\d*)\s*(?:million|mill/cumm).*(?:rbc|red)'],
        'platelets': [r'(?:platelets?|plt|thrombocytes?)[:\s]*(\d+\.?\d*)', r'(\d+\.?\d*)\s*(?:/cumm|lakhs?|thousand).*(?:platelet|plt)'],
        'glucose': [r'(?:glucose|sugar|fbs|rbs|blood\s*sugar)[:\s]*(\d+\.?\d*)', r'(\d+\.?\d*)\s*(?:mg/dl|mg%).*(?:glucose|sugar)'],
        'cholesterol': [r'(?:cholesterol|chol|total\s*cholesterol)[:\s]*(\d+\.?\d*)', r'(\d+\.?\d*)\s*(?:mg/dl|mg%).*(?:cholesterol)'],
        'triglycerides': [r'(?:triglycerides?|tg)[:\s]*(\d+\.?\d*)', r'(\d+\.?\d*)\s*(?:mg/dl|mg%).*(?:triglyceride)'],
        'hdl': [r'(?:hdl|hdl[\s-]*cholesterol)[:\s]*(\d+\.?\d*)'],
        'ldl': [r'(?:ldl|ldl[\s-]*cholesterol)[:\s]*(\d+\.?\d*)'],
        'creatinine': [r'(?:creatinine|creat)[:\s]*(\d+\.?\d*)', r'(\d+\.?\d*)\s*(?:mg/dl).*(?:creatinine)'],
        'urea': [r'(?:urea|bun|blood\s*urea)[:\s]*(\d+\.?\d*)'],
        'uric_acid': [r'(?:uric\s*acid)[:\s]*(\d+\.?\d*)'],
        'bilirubin': [r'(?:bilirubin|total\s*bilirubin)[:\s]*(\d+\.?\d*)'],
        'sgot': [r'(?:sgot|ast|aspartate)[:\s]*(\d+\.?\d*)'],
        'sgpt': [r'(?:sgpt|alt|alanine)[:\s]*(\d+\.?\d*)'],
        'tsh': [r'(?:tsh|thyroid)[:\s]*(\d+\.?\d*)'],
        'hba1c': [r'(?:hba1c|glycated|a1c)[:\s]*(\d+\.?\d*)'],
        'vitamin_d': [r'(?:vitamin\s*d|vit\s*d|25.*hydroxy)[:\s]*(\d+\.?\d*)'],
        'vitamin_b12': [r'(?:vitamin\s*b12|vit\s*b12|b12)[:\s]*(\d+\.?\d*)'],
        'iron': [r'(?:iron|serum\s*iron)[:\s]*(\d+\.?\d*)'],
        'calcium': [r'(?:calcium|ca)[:\s]*(\d+\.?\d*)'],
        'sodium': [r'(?:sodium|na)[:\s]*(\d+\.?\d*)'],
        'potassium': [r'(?:potassium|k)[:\s]*(\d+\.?\d*)'],
        'bp_systolic': [r'(?:bp|blood\s*pressure)[:\s]*(\d{2,3})\s*/\s*\d{2,3}', r'systolic[:\s]*(\d{2,3})'],
        'bp_diastolic': [r'(?:bp|blood\s*pressure)[:\s]*\d{2,3}\s*/\s*(\d{2,3})', r'diastolic[:\s]*(\d{2,3})'],
    }
    
    for key, pattern_list in patterns.items():
        for pattern in pattern_list:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                try:
                    val = float(match.group(1))
                    if val > 0:  # Only add positive values
                        values[key] = val
                        break
                except:
                    continue
    
    print(f"Regex extracted values: {values}")
    return values if values else None


# 1. Login/Home Page
def index(request):
    if request.user.is_authenticated:
        return redirect('dashboard')
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('dashboard')
        else:
            messages.error(request, 'Invalid username or password.')
    return render(request, 'index.html')

# 2. Registration Logic
def register(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('dashboard')
    else:
        form = UserCreationForm()
    return render(request, 'register.html', {'form': form})

# 3. Logout Logic - FIXED REDIRECT NAME
def logout_view(request):
    logout(request)
    return redirect('login') 

# 4. Dashboard + Profile Update + Analytics
@login_required
def dashboard(request):
    # Initialize Session Data to avoid Errors
    if 'my_reports' not in request.session:
        request.session['my_reports'] = []  # Start with empty reports list
    
    if 'user_profile' not in request.session:
        request.session['user_profile'] = {
            'full_name': request.user.username,
            'email': request.user.email if request.user.email else "user@health.com",
            'dob': '',
            'gender': 'Not Set',
            'phone': 'Not Set',
            'blood_group': 'Not Set'
        }

    show_analytics = False

    if request.method == 'POST':
        # Action A: File Upload
        if request.FILES.get('medical_file'):
            uploaded_file = request.FILES['medical_file']
            
            # Try to extract values from the image
            extracted_values, ocr_text = extract_medical_values_from_image(uploaded_file)
            
            # If extraction failed or OCR not available, don't add fake data
            if not extracted_values:
                print("No values extracted - report will be empty or fallback")
                # Don't generate fake data - only use actual extracted values
                extracted_values = {}
            
            # Create report with ALL extracted values
            new_report = {
                'upload_date': datetime.date.today().strftime("%b %d, %Y"),
                'report_name': uploaded_file.name,
            }
            
            # Store the OCR text for AI analysis
            if ocr_text:
                new_report['ocr_text'] = ocr_text
            
            # Add ALL extracted values dynamically
            if extracted_values:
                for key, value in extracted_values.items():
                    new_report[key] = value
            
            reports = request.session['my_reports']
            reports.insert(0, new_report)
            request.session['my_reports'] = reports
            request.session.modified = True
            
            # Redirect after successful upload to refresh the page with new data
            return redirect('dashboard')

        # Action B: Profile Update
        elif 'update_profile' in request.POST:
            request.session['user_profile'] = {
                'full_name': request.POST.get('full_name'),
                'email': request.POST.get('email'),
                'dob': request.POST.get('dob'),
                'gender': request.POST.get('gender'),
                'phone': request.POST.get('phone'),
                'blood_group': request.POST.get('blood_group'),
            }
            request.session.modified = True

    # Safely get profile data for the template
    profile = request.session.get('user_profile', {})
    latest = request.session['my_reports'][0] if request.session['my_reports'] else {}

    context = {
        'username': profile.get('full_name'),
        'user_email': profile.get('email'),
        'user_dob': profile.get('dob'),
        'user_gender': profile.get('gender'),
        'user_phone': profile.get('phone'),
        'user_blood_group': profile.get('blood_group'),
        'latest': latest,
        'reports': request.session['my_reports'],
        'show_analytics': show_analytics
    }
    return render(request, 'dashboard.html', context)

def password_reset_request(request):
    if request.method == 'POST':
        username_input = request.POST.get('email') 
        pin_input = request.POST.get('pin')
        new_pass = request.POST.get('new_password')

        if pin_input == "1234":
            try:
                # This is why we need 'from django.contrib.auth.models import User'
                user = User.objects.get(username=username_input)
                user.set_password(new_pass)
                user.save()
                messages.success(request, "Success! Password has been updated.")
                return redirect('login') 
            except User.DoesNotExist:
                messages.error(request, "Error: That username does not exist.")
        else:
            messages.error(request, "Error: Invalid Security PIN.")
    



# ============ LLM AI ENDPOINTS ============

@login_required
def analyze_report(request):
    """Analyze a medical report using AI"""
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            report_data = data.get('report', {})
            
            # Get user profile for personalized analysis
            user_profile = request.session.get('user_profile', {})
            
            # Call LLM service
            analysis = llm_service.analyze_medical_report(report_data, user_profile)
            
            return JsonResponse({
                'success': True,
                'analysis': analysis
            })
        except Exception as e:
            return JsonResponse({
                'success': False,
                'error': str(e)
            }, status=500)
    
    return JsonResponse({'error': 'POST method required'}, status=405)


@login_required
def explain_term(request):
    """Explain a medical term in simple language"""
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            term = data.get('term', '')
            
            if not term:
                return JsonResponse({'error': 'Term is required'}, status=400)
            
            explanation = llm_service.explain_medical_term(term)
            
            return JsonResponse({
                'success': True,
                'explanation': explanation
            })
        except Exception as e:
            return JsonResponse({
                'success': False,
                'error': str(e)
            }, status=500)
    
    return JsonResponse({'error': 'POST method required'}, status=405)


@login_required
def ai_chat(request):
    """Chat with the medical AI assistant"""
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            user_message = data.get('message', '')
            conversation_history = data.get('history', [])
            
            if not user_message:
                return JsonResponse({'error': 'Message is required'}, status=400)
            
            response = llm_service.chat(user_message, conversation_history)
            
            return JsonResponse({
                'success': True,
                'response': response
            })
        except Exception as e:
            return JsonResponse({
                'success': False,
                'error': str(e)
            }, status=500)
    
    return JsonResponse({'error': 'POST method required'}, status=405)


@login_required
def delete_report(request, report_index):
    """Delete a medical report from the session"""
    if request.method == 'POST':
        if 'my_reports' in request.session:
            try:
                reports = request.session['my_reports']
                if 0 <= report_index < len(reports):
                    deleted_report = reports.pop(report_index)
                    request.session['my_reports'] = reports
                    request.session.modified = True
                    return JsonResponse({
                        'success': True, 
                        'message': f"Report {deleted_report.get('report_name', 'Unknown')} deleted."
                    })
                else:
                    return JsonResponse({'success': False, 'error': 'Invalid report index.'}, status=400)
            except Exception as e:
                return JsonResponse({'success': False, 'error': str(e)}, status=500)
        else:
            return JsonResponse({'success': False, 'error': 'No reports found in session.'}, status=404)
    
    return JsonResponse({'error': 'POST method required'}, status=405)